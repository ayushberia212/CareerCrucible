<?php
session_start();
$_SESSION['user_id']=253;
include 'connection.php';
$con=connect();


$slot_id=$_GET["slot_id"];
$con_id=$_GET["con_id"];
  if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
  }
  // echo($con_id);
//echo "Connected successfully";
$sql1="SELECT slot_date,from_time,to_time FROM freeslot WHERE slot_id=$slot_id";
$result=$con->query($sql1);
$row=$result->fetch_assoc();
$slot_date=$row['slot_date'];
$from_time=$row['from_time'];
$to_time=$row['to_time'];

$user=$_SESSION['user_id'];
$sql="INSERT INTO booked_slot(slot_id,user_id,consultant_id,slot_date,from_time,to_time) VALUES ('$slot_id','$user','$con_id','$slot_date','$from_time','$to_time')";
//$result=mysqli_query($con,$query);
  $result1=$con->query($sql);
  echo($result1);
  if($result1){
  echo ("hi");

  $sql1="DELETE FROM freeslot WHERE slot_id=$slot_id";
  $result1=$con->query($sql1);

  if($result1)
  {
    ?>
        <script>alert('successfully registered ');</script>
        <?php
      header('location: ../booked_slot.php?slot_id='.$slot_id);
  }
  else
  {
    ?>
        <script>alert('registeration failed ');</script>
        <?php
  }


  }



?>
