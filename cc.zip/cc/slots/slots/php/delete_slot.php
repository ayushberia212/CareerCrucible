<?php
session_start();
include 'connection.php';
$con=connect();

$slot_id=$_GET['id'];

	$con_id=$_SESSION['consultant_id'];
	if (!$con) {
    	die("Connection failed: " . mysqli_connect_error());
  	}
  	$sql = "DELETE FROM freeslot WHERE	slot_id='$slot_id' ";
    $result = $con->query($sql);
if($result){
	echo"<script>alert('slot is deleted')</script>";
	header('location: ..\freeslot.php');
}



?>