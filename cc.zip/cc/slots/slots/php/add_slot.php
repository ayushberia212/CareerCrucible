<?php
session_start();
include 'connection.php';
$con=connect();


$slot_date=$_POST['slot_date'];
$from_time=$_POST['from_time'];
$num_slot=$_POST['num_slot']; 
if(isset($_SESSION['consultant_id'])){
  $con_id=$_SESSION['consultant_id'];
  if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
  }
//echo "Connected successfully";
  // echo ($from_time);
  for($i=0;$i<$num_slot;$i++){
  $to_time = date("H:i:s", strtotime( "$from_time + 20 mins"));

  $query="INSERT INTO freeslot (consultant_id,slot_date,from_time,to_time) VALUES ('$con_id','$slot_date','$from_time','$to_time')";
  $from_time=$to_time;
//$result=mysqli_query($con,$query);
  $result=mysqli_query($con,$query);
  echo($result);

  echo ("hi");
//print_r($array);
}

  if($result)
  {
    ?>
        <script>alert('slot added successfully ');</script>
        <?php

    // $_SESSION['user']=$username;
    echo ($to_time);
      header('location: ../freeslot.php');
  }
  else
  {
    ?>
        <script>alert('fail to add slot ');</script>
        <?php
  }

}
else {
  header('location: index.php');
}

?>
