  <?php

    session_start();
    require("../../db_connect.php");
    if (!$db) {
        die("Connection failed: " . mysqli_connect_error());
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Consultant free slots</title>
    <!-- <link rel="stylesheet" href="css/style.login.css" > -->

    <!-- we use cdn but you can also include local files located in css directory-->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.student_view.css">
    <!-- Google fonts - Roboto Condensed for headings, Open Sans for copy-->
    <link rel="stylesheet" href="css/font-min.css">

    <script src="js/jquery.min.js"></script>


    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">



</head>

<body>


    
<header class="header">
      <div class="sticky-wrapper">
        <div role="navigation" class="navbar navbar-default">
          <div class="container">
            <div class="navbar-header">
              <button type="button" data-toggle="collapse" data-target=".navbar-collapse" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button><a href="#intro" class="navbar-brand scroll-to" id="top"><p>CareerCrucible</p></a>
            </div>
            <div id="navigation" class="collapse navbar-collapse">
              <ul class="nav navbar-nav navbar-right">
                <li ><a href="/">Home</a></li>
              
                <li class="dropdown">
                  <a class="dropdown-toggle" data-toggle="dropdown" href="#"id="test">Resources<span class="caret"></span></a>
                <ul class="dropdown-menu">
            <li><a href="/engcolleges/"id="test1" >Engineering colleges</a></li>
            <li><a href="/engexams/"id="test1" >Engineering exams</a></li>
             <li><a href="/calendar/" id="test1">Exam calender</a></li>
             <li><a href="/branchinfo/"id="test1" >Branch Info</a></li>
             <li><a href="/branchreview/" id="test1">Branch Review</a></li>
          </ul>
        </li>

          <li><a href="/news/">News</a></li>
                <li><a href="/forum/">Forum</a></li>
                <li><a href="/counselling/">Counselling</a></li>
                <?php
                if(!isset($_SESSION['student_id'])){
                  echo '<li><a href="../student/login.php"><span class="glyphicon glyphicon-user"></span>Login</a></li>';
                } 
                else {
                  echo '<li><a href="../student/php/logout.php"><span class="glyphicon glyphicon-user"></span>Logout</a></li>';
                }
                ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>

        <form action="student_view.php" method="get">
            <label>College : </label>
            <input id="college" name="college" type="text" class="college" placeholder="VJTI-mumbai" />
            <label name="specialization">Specialization : </label>
            <input id="spec" name="spec" type="text" class="spec" placeholder="Computer Engg." />
            <label name="specialization">Language : </label>
            <input id="lang" name="lang" type="text" class="spec" placeholder="Hindi" />
            <input type="submit" class="button" value="ADD" name="login" />
        </form>


        <?php
if(isset($_GET['college'])){
  $college = strtolower($_GET['college']);
  $spec = strtolower($_GET['spec']);
  $lang = strtolower($_GET['lang']);
$sql="SELECT * FROM consultant WHERE LOWER(college) LIKE '%$college%' AND LOWER(specialization) LIKE '%$spec%' AND LOWER(languages) LIKE '%$lang%'";
}
else{
$sql = "SELECT * FROM consultant";
}
$result = $db->query($sql);
if($result->num_rows > 0){
echo '<div class="wrapper">';
while($row=$result->fetch_assoc()){
echo'
        <div class="col-xs-18 col-sm-6 col-md-2">
          <div class="thumbnail">
            
              <div class="caption">
              <a href="consultant_prof.php?id='.$row['consultant_id'].'" title="View">
                <h4>'.$row['name'].'</h4>
                <p><label>College:</label> <span>'.$row['college'].'</span></p>
                <p><label>Degree:</label> <span>'.$row['degree'].'</span></p>
                <p><label>Specialization:</label> <span>'.$row['specialization'].'</span></p></a>
                <p><label>Laguages:</label> <span>'.$row['languages'].'</span></p></a>
            </div>
          </div>
        </div>
';
}
echo '</div>';
}

?>
            <!-- <img src="http://placehold.it/500x250/EEE"> -->
</body>

</html>