-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2016 at 10:01 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `career_crucible`
--

-- --------------------------------------------------------

--
-- Table structure for table `booked_slot`
--

CREATE TABLE IF NOT EXISTS `booked_slot` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `slot_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `consultant_id` int(11) NOT NULL,
  `slot_date` date DEFAULT NULL,
  `from_time` time DEFAULT NULL,
  `to_time` time DEFAULT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `booked_slot`
--

INSERT INTO `booked_slot` (`booking_id`, `slot_id`, `user_id`, `consultant_id`, `slot_date`, `from_time`, `to_time`) VALUES
(60, 105, 253, 16, '2016-06-06', '21:00:00', '21:30:00'),
(61, 104, 253, 16, '2016-06-06', '20:30:00', '21:00:00'),
(62, 107, 253, 16, '2016-06-06', '22:00:00', '22:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `consultant`
--

CREATE TABLE IF NOT EXISTS `consultant` (
  `consultant_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `contactno` varchar(250) DEFAULT NULL,
  `college` varchar(250) DEFAULT NULL,
  `degree` varchar(250) DEFAULT NULL,
  `specialization` varchar(250) DEFAULT NULL,
  `passing_year` varchar(250) DEFAULT NULL,
  `languages` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`consultant_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `consultant`
--

INSERT INTO `consultant` (`consultant_id`, `name`, `email`, `password`, `contactno`, `college`, `degree`, `specialization`, `passing_year`, `languages`) VALUES
(16, 'Shobhit', 'shobhsd@gmail.com', '8cb2237d0679ca88db6464eac60da96345513964', '9542980324', 'BITS hyderabad', 'B.E', 'Civil', '2018', 'English Hindi ');

-- --------------------------------------------------------

--
-- Table structure for table `freeslot`
--

CREATE TABLE IF NOT EXISTS `freeslot` (
  `slot_id` int(11) NOT NULL AUTO_INCREMENT,
  `consultant_id` int(11) NOT NULL,
  `slot_date` date NOT NULL,
  `from_time` time NOT NULL,
  `to_time` time DEFAULT NULL,
  PRIMARY KEY (`slot_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=122 ;

--
-- Dumping data for table `freeslot`
--

INSERT INTO `freeslot` (`slot_id`, `consultant_id`, `slot_date`, `from_time`, `to_time`) VALUES
(93, 11, '2016-05-28', '10:00:00', '10:30:00'),
(95, 11, '2016-05-28', '08:30:00', '09:00:00'),
(96, 11, '2016-05-28', '09:00:00', '09:30:00'),
(110, 16, '2016-06-05', '10:30:00', '10:50:00'),
(111, 16, '2016-06-05', '10:50:00', '11:10:00'),
(112, 16, '2016-06-05', '11:10:00', '11:30:00'),
(113, 16, '2016-06-05', '11:30:00', '11:50:00'),
(114, 16, '2016-06-09', '10:00:00', '10:20:00'),
(115, 16, '2016-06-09', '10:20:00', '10:40:00'),
(116, 16, '2016-06-09', '10:40:00', '11:00:00'),
(117, 16, '2016-06-09', '11:00:00', '11:20:00'),
(118, 16, '2016-06-09', '11:20:00', '11:40:00'),
(119, 16, '2016-06-09', '11:40:00', '12:00:00'),
(120, 16, '2016-06-09', '12:00:00', '12:20:00'),
(121, 16, '2016-06-09', '12:20:00', '12:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `contactno` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `name`, `email`, `password`, `contactno`) VALUES
(1, 'John', 'abc@xyz.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '123456'),
(3, 'Shobhit', 'shobhsd@gmail.com', '8cb2237d0679ca88db6464eac60da96345513964', '9542980324');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE IF NOT EXISTS `student_details` (
  `id` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `main` int(11) NOT NULL,
  `adv` int(11) NOT NULL,
  `bits` int(11) NOT NULL,
  `other1name` varchar(200) NOT NULL,
  `other1marks` int(11) NOT NULL,
  `other2name` varchar(200) NOT NULL,
  `other2marks` int(11) NOT NULL,
  `other3name` varchar(200) NOT NULL,
  `other3marks` int(11) NOT NULL,
  `board` int(11) NOT NULL,
  `branch1` varchar(50) NOT NULL,
  `branch2` varchar(50) NOT NULL,
  `branch3` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `college1` varchar(50) NOT NULL,
  `college2` varchar(50) NOT NULL,
  `college3` varchar(50) NOT NULL,
  `comment` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`id`, `rank`, `main`, `adv`, `bits`, `other1name`, `other1marks`, `other2name`, `other2marks`, `other3name`, `other3marks`, `board`, `branch1`, `branch2`, `branch3`, `state`, `college1`, `college2`, `college3`, `comment`) VALUES
(1, 1, 2, 3, 4, '5', 6, '8', 7, '9', 0, 1, '2', '3', '4', 'Andaman and Nicobar Islands', '6', '7', '8', '9');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
