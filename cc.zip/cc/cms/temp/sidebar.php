<!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <!-- <a href="index1.php">
                        Blog
                    </a> -->
                </li>
                <li>
                    <!-- <a href="php/profile.php?username=<?php echo $_SESSION['user']; ?>">Profile</a> -->
                </li>
                <li>
                    <p>Dashboard</p>
                </li>
                <li>
                    <a href="addnews.php">Add News</a>
                </li>
                <li>
                    <a href="addblog.php">Add blog</a>
                </li>
				<li>
                    <a href="insert_clg_data.php">Add College Data</a>
                </li>
				<li>
                    <a href="insert_branch_review.php">Add Branch Review</a>
                </li>
				<li>
                    <a href="insert_branch_info.php">Add Branch Information</a>
                </li>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->