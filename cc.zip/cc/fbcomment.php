<?php 
echo'<div class="container conta " style="margin-top:10px;">
  <div class="cont col-md-9">
<div class="fb-comments" data-href="http://careercrucible.com/eng%20colleges/colleges/iit%20roorkee.html" data-width="752" data-numposts="7"></div>
</div>
</div>'
?>