<?php

echo'<div class="tags section-gray"style="margin-top:30px;">
              <h4 style="text-align:left;border-bottom:1px solid grey;margin-top:10px;margin-left:5px;">Popular Tags</h4>
              <div class="popular-tags "style="font-family:myriad pro;">
            <ul>
            <li><a href="/engcolleges/colleges/bits_pilani.php">BITS Pilani</a></li>
            <li><a href="/engexams/exams/jeemain.php">Jee Mains</a></li>
            <li><a href="/engexams/exams/uptu.php">UPTU</a></li>
            <li><a href="/branchreview/iits/delhi-electrical.php">IIT Delhi Electrical</a></li>
            <li><a href="/engcolleges/colleges/vit_vellore.php">VIT Vellore</a></li>
            <li><a href="/branchinfo/branches/civil.php">Civil Engineering</a></li>
            <li style="padding-bottom:8px;"><a href="/engcolleges/colleges/iit_mad.php">IIT Madras</a></li>
            </ul>
           </div>     
      </div>'

      ?>