<?php
echo'<div class="fb-page"
  data-href="https://www.facebook.com/thecareercrucible/?fref=ts" 
  data-width="340"
  data-hide-cover="false"
  data-show-facepile="true"style="margin-top:50px;"></div>'
  ?>