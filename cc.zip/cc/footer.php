<?php
echo' <div class="footer-section">
         <div class="container">
          <div class="footer-grids">

            <ul class="footerlinks">
              <li><a href="#">About Us</a></li>
                <li><a href="#">Our Team</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="../../contactus.html">Contact</a></li>
                <li><a href="#">FAQs</a></li>
               <li><a href="#">Feedback</a></li>
            </ul>
            <div class="copyright">&copy; Career Crucible. All Rights Reserved.</div>
        </div>  



          </div>
        </div>';
  ?>