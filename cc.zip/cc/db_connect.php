<?php
$db=mysqli_connect("localhost","root","","cc") or die("Could not Connect My Sql");
?>